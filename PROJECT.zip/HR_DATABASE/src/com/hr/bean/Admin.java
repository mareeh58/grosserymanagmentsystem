package com.hr.bean;

public class Admin {
 private String admin_name;
 private String Password;

public String getAdmin_name() {
	return admin_name;
}
public void setAdmin_name(String admin_name) {
	this.admin_name = admin_name;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
 
}
