package com.hr.bean;

public class Seller {
private String seller_id;
private String seller_name;
private String seller_gender;
private String Password;
public String getSeller_id() {
	return seller_id;
}
public void setSeller_id(String seller_id) {
	this.seller_id = seller_id;
}
public String getSeller_name() {
	return seller_name;
}
public void setSeller_name(String seller_name) {
	this.seller_name = seller_name;
}
public String getSeller_gender() {
	return seller_gender;
}
public void setSeller_gender(String seller_gender) {
	this.seller_gender = seller_gender;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}

}
