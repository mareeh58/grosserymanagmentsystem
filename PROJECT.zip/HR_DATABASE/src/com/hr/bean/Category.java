package com.hr.bean;

public class Category {
	private String category_id;
	private String catageory_name;
	private String Description;
	public String getCategory_id() {
		return category_id;
	}
	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}
	public String getCatageory_name() {
		return catageory_name;
	}
	public void setCatageory_name(String catageory_name) {
		this.catageory_name = catageory_name;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}

	}


