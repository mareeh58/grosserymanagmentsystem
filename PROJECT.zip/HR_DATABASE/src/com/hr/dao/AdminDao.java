package com.hr.dao;


import com.hr.util.DBUtil;
public class AdminDao {

    public static void insert_admin(String admin_name, String password) throws Exception {
        String sql = "INSERT INTO ADMIN (ADMIN_NAME, PASSWORD) VALUES ('" + admin_name + "', '" + password + "')";
        DBUtil.executeQuery(sql);
        System.out.println("Admin inserted");
        DBUtil.conn.close();
    }
    public static void update_admin(String admin_name, String password) throws Exception {
        String sql = "UPDATE ADMIN SET PASSWORD = '" + password + "' WHERE ADMIN_NAME = '" + admin_name + "'";
        DBUtil.executeQuery(sql);
        System.out.println("Admin updated");
        DBUtil.conn.close();
    }
        public static void delete_admin(String admin_name) throws Exception {
            String sql = "DELETE FROM ADMIN WHERE ADMIN_NAME = '" + admin_name + "'";
            DBUtil.executeQuery(sql);
            System.out.println("Admin deleted");
            DBUtil.conn.close();
        }
    }