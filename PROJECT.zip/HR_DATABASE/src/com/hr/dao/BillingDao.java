package com.hr.dao;


import com.hr.dao.CategoryDao;
import com.hr.util.DBUtil;
public class BillingDao{
	public static void insert_billing(String items , String price, String total) throws Exception{
		String sql = "INSERT INTO BILLING(ITEMS, PRICE, TOTAL) VALUES ('"+items +"','"+ price +"','"+ total+"')";
		  DBUtil.executeQuery(sql);
	        System.out.println("Billing inserted");
	        DBUtil.conn.close();
	}
	   public static void delete_billing() throws Exception {
           String sql = "DELETE FROM * BILLING";
           DBUtil.executeQuery(sql);
           System.out.println("Bill deleted");
           DBUtil.conn.close();
       }}
