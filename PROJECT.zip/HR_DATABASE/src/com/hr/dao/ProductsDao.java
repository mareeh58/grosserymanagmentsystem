package com.hr.dao;



import com.hr.dao.ProductsDao;
import com.hr.util.DBUtil;

public class ProductsDao {

    public static void insert_product(String product_id, String product_name, String product_company, String product_price,String quantity) throws Exception {
        String sql = "INSERT INTO PRODUCTS (PRODUCT_ID, PRODUCT_NAME, PRODUCT_COMPANY, PRODUCT_PRICE, QUANTITY) VALUES (" 
                      + product_id + ", '" + product_name + "', '" + product_company + "', " + product_price + ", " + quantity + ")";
        DBUtil.executeQuery(sql);
        System.out.println("Product inserted");
        DBUtil.conn.close();
    }


        public static void update_product(String product_id, String product_name, String product_company,String product_price,String quantity) throws Exception {
            String sql = "UPDATE PRODUCTS SET PRODUCT_NAME = '" + product_name + "', PRODUCT_COMPANY = '" + product_company + 
                          "', PRODUCT_PRICE = " + product_price + ", QUANTITY = " + quantity + 
                          " WHERE PRODUCT_ID = " + product_id;
            DBUtil.executeQuery(sql);
            System.out.println("Product updated");
            DBUtil.conn.close();
        }

            public static void delete_product(String product_id) throws Exception {
                String sql = "DELETE FROM PRODUCTS WHERE PRODUCT_ID = " + product_id;
                DBUtil.executeQuery(sql);
                System.out.println("Product deleted");
                DBUtil.conn.close();
            }
}