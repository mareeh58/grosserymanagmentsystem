package com.hr.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hr.bean.Category;

import com.hr.dao.CategoryDao;
import com.hr.util.DBUtil;
public class CategoryDao {

	public void getAllCategories() throws Exception {
        ArrayList<Category> categorylist = new ArrayList<Category>();
        String sql = "SELECT * FROM CATEGORY";
        ResultSet rs = DBUtil.executeQuery(sql);
		while(rs.next()) {
			Category cat=new Category();
			cat.setCategory_id(rs.getString(1));
			cat.setCatageory_name(rs.getString(2));
			cat.setDescription(rs.getString(3));
			categorylist.add(cat);
			
			
		}
			
		}

	    public static void insert_category(String category_id , String category_name, String description) throws Exception {
	        String sql = "INSERT INTO CATEGORY (CATEGORY_ID, CATEGORY_NAME, DESCRIPTION) VALUES ('"+category_id +"','"+ category_name +"','"+ description+"')";
	        DBUtil.executeQuery(sql);
	        System.out.println("Category inserted");
	        DBUtil.conn.close();
	    }
	

	        public static void update_category(String category_id, String category_name, String description) throws Exception {
	            String sql = "UPDATE CATEGORY SET CATEGORY_NAME = '" + category_name + "', DESCRIPTION = '" + description + 
	                          "' WHERE CATEGORY_ID = " + category_id;
	            DBUtil.executeQuery(sql);
	            System.out.println("Category updated");
	            DBUtil.conn.close();
	        }
	   

	        public static void delete_category(String category_id) throws Exception {
                String sql = "DELETE FROM CATEGORY WHERE CATEGORY_ID = " + category_id;
                DBUtil.executeQuery(sql);
                System.out.println("Category deleted");
                DBUtil.conn.close();
            }
	        public static List<Category> getAllCategories1() {
	            List<Category> categoryList = new ArrayList<>();
	            try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "sixjune","oracle")) {
	                String query = "SELECT category_id, category_name, description FROM categories";
	                PreparedStatement preparedStatement = connection.prepareStatement(query);
	                ResultSet rs = preparedStatement.executeQuery();

	                while (rs.next()) {
	                    Category category = new Category();
	                    category.setCategory_id(rs.getString("category_id"));
	                    category.setCatageory_name(rs.getString("category_name"));
	                    category.setDescription(rs.getString("description"));

	                    categoryList.add(category);
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	            return categoryList;
	        }

	        }
