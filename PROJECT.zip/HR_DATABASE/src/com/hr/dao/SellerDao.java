package com.hr.dao;

import java.util.List;

import com.hr.dao.SellerDao;
import com.hr.util.DBUtil;
public class SellerDao {

    public static void insert_seller(String seller_id, String seller_name, String seller_gender, String password) throws Exception {
        String sql = "INSERT INTO SELLER (SELLER_ID, SELLER_NAME, SELLER_GENDER,PASSWORD) VALUES (" 
                                                      + seller_id + ", '" + seller_name + "', '" + seller_gender + "','"+password+"')";
        DBUtil.executeQuery(sql);
        System.out.println("Seller inserted");
        DBUtil.conn.close();
    }


        public static void update_seller(String seller_id, String seller_name, String seller_gender,String password) throws Exception {
            String sql = "UPDATE SELLER SET PASSWORD='"+password+"',SELLER_NAME = '" + seller_name + "', SELLER_GENDER = '" + seller_gender + "' "
            		+ "WHERE SELLER_ID = '" + seller_id + "'";
            DBUtil.executeQuery(sql);
            System.out.println("Seller updated");
            DBUtil.conn.close();
        }

            public static void delete_seller(String seller_id) throws Exception {
                String sql = "DELETE FROM SELLER WHERE SELLER_ID = '" + seller_id + "'";
                DBUtil.executeQuery(sql);
                System.out.println("Seller deleted");
                DBUtil.conn.close();
            }


			public static List<SellerDao> getAllSellers() {
				// TODO Auto-generated method stub
				return null;
			}
        }