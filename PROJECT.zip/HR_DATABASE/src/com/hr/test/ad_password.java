package com.hr.test;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

public class ad_password {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public ad_password() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame = new JFrame();
	        frame.getContentPane().setBackground(new Color(255, 255, 255));
	        frame.setBounds(100, 100, 400, 200);
	        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        frame.getContentPane().setLayout(null);
	        
	        JLabel lblAdminPassword = new JLabel("Admin Password");
	        lblAdminPassword.setForeground(new Color(0, 102, 51));
	        lblAdminPassword.setFont(new Font("Rockwell", Font.BOLD, 16));
	        lblAdminPassword.setBounds(50, 50, 150, 24);
	        frame.getContentPane().add(lblAdminPassword);
	        
	        JPasswordField adminPasswordField = new JPasswordField();
	        adminPasswordField.setBounds(210, 50, 120, 24);
	        frame.getContentPane().add(adminPasswordField);
	        
	        final JButton btnAdminLogin = new JButton("Login");
	        btnAdminLogin.setForeground(new Color(255, 255, 255));
	        btnAdminLogin.setBackground(new Color(0, 102, 51));
	        btnAdminLogin.setFont(new Font("Sylfaen", Font.BOLD, 16));
	        btnAdminLogin.setBounds(140, 100, 100, 30);
	        frame.getContentPane().add(btnAdminLogin);
	        btnAdminLogin.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	if(e.getSource()==btnAdminLogin) {
	            	RadioButtons window = new RadioButtons();
	                window.f_radio.setVisible(true);}
	               
	            }
	        });
	}
}
