package com.hr.test;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import com.hr.dao.SellerDao;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Seller extends Swing  {
    private static final long serialVersionUID = 1L;
    JFrame frame;
    private JPanel panel;
    private JTable table;
    private JTable table_1;
    private JTextField textField_sid;
    private JTextField textField_sellnam;
    private JTextField textField_selpass;
    private JTextField textField_sellgen;
    private JTable table_2;
    private JTable table_3;

    /**
     * Launch the application.
     */
   

    /**
     * Create the application.
     */
    public Seller() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 1029, 613);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        panel = new JPanel();
        panel.setBackground(new Color(0, 102, 51));
        panel.setForeground(new Color(0, 102, 51));
        panel.setBounds(0, 0, 1015, 576);
        frame.getContentPane().add(panel);
        panel.setLayout(null);

        JPanel panel_1 = new JPanel();
        panel_1.setBounds(74, 21, 909, 534);
        panel.add(panel_1);
        panel_1.setLayout(null);

        final JButton btnNewButton_1_1 = new JButton("Add");
        btnNewButton_1_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == btnNewButton_1_1) {
                    try {
                        SellerDao.insert_seller(textField_sid.getText(), textField_sellnam.getText(), textField_sellgen.getText(), textField_selpass.getText());
                        
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });

        JButton btnNewButton_1_2 = new JButton("Delete");
        btnNewButton_1_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SellerDao.delete_seller(textField_sid.getText());
                    
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        btnNewButton_1_2.setBounds(393, 211, 102, 29);
        panel_1.add(btnNewButton_1_2);
        btnNewButton_1_2.setForeground(new Color(255, 255, 255));
        btnNewButton_1_2.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_1_2.setBackground(new Color(0, 102, 51));

        JButton btnNewButton_1_3 = new JButton("Clear");
        btnNewButton_1_3.setBounds(542, 211, 81, 29);
        panel_1.add(btnNewButton_1_3);
        btnNewButton_1_3.setForeground(new Color(255, 255, 255));
        btnNewButton_1_3.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_1_3.setBackground(new Color(0, 102, 51));
        btnNewButton_1_3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        JButton btnNewButton_1 = new JButton("Edit");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SellerDao.update_seller(textField_sid.getText(), textField_sellgen.getText(), textField_selpass.getText(), textField_sellnam.getText());
                  
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        btnNewButton_1.setBounds(253, 211, 102, 29);
        panel_1.add(btnNewButton_1);
        btnNewButton_1.setForeground(new Color(255, 255, 255));
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_1.setBackground(new Color(0, 102, 51));

        btnNewButton_1_1.setBounds(123, 211, 81, 29);
        panel_1.add(btnNewButton_1_1);
        btnNewButton_1_1.setForeground(new Color(255, 255, 255));
        btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_1_1.setBackground(new Color(0, 102, 51));

        JLabel lblNewLabel_1 = new JLabel("Seller_id");
        lblNewLabel_1.setForeground(new Color(0, 102, 51));
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel_1.setBounds(102, 83, 102, 20);
        panel_1.add(lblNewLabel_1);

        JLabel lblNewLabel_1_1 = new JLabel("Seller_name");
        lblNewLabel_1_1.setForeground(new Color(0, 102, 51));
        lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel_1_1.setBounds(102, 134, 102, 20);
        panel_1.add(lblNewLabel_1_1);

        JLabel lblNewLabel_1_2 = new JLabel("Password");
        lblNewLabel_1_2.setForeground(new Color(0, 102, 51));
        lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel_1_2.setBounds(462, 83, 102, 20);
        panel_1.add(lblNewLabel_1_2);

        JLabel lblNewLabel_1_3 = new JLabel("Gender");
        lblNewLabel_1_3.setForeground(new Color(0, 102, 51));
        lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel_1_3.setBounds(462, 134, 102, 20);
        panel_1.add(lblNewLabel_1_3);

        JLabel lblNewLabel_2 = new JLabel("Manage Sellers");
        lblNewLabel_2.setForeground(new Color(0, 102, 51));
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
        lblNewLabel_2.setBounds(286, 10, 245, 44);
        panel_1.add(lblNewLabel_2);

        table = new JTable();
        table.setBounds(227, 418, 0, 0);
        panel_1.add(table);

        table_1 = new JTable();
        table_1.setBounds(214, 419, 0, 0);
        panel_1.add(table_1);

        textField_sid = new JTextField();
        textField_sid.setBounds(218, 84, 154, 23);
        panel_1.add(textField_sid);
        textField_sid.setColumns(10);

        textField_sellnam = new JTextField();
        textField_sellnam.setColumns(10);
        textField_sellnam.setBounds(218, 135, 154, 23);
        panel_1.add(textField_sellnam);

        textField_selpass = new JTextField();
        textField_selpass.setColumns(10);
        textField_selpass.setBounds(578, 83, 154, 23);
        panel_1.add(textField_selpass);

        textField_sellgen = new JTextField();
        textField_sellgen.setColumns(10);
        textField_sellgen.setBounds(578, 135, 154, 23);
        panel_1.add(textField_sellgen);

        JLabel lblNewLabel_3 = new JLabel("Sellers List");
        lblNewLabel_3.setForeground(new Color(0, 102, 51));
        lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel_3.setBounds(331, 260, 145, 29);
        panel_1.add(lblNewLabel_3);

        table_2 = new JTable();
        table_2.setBounds(291, 397, 0, 0);
        panel_1.add(table_2);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(38, 307, 807, 227);
        panel_1.add(scrollPane);

        table_3 = new JTable();
        scrollPane.setViewportView(table_3);
        table_3.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{
                        "Seller_id", "Seller_name", "Password", "Gender"
                }
        ));

        final JButton btnNewButton = new JButton("Home");
        btnNewButton.setForeground(new Color(0, 102, 51));
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == btnNewButton) {
                    RadioButtons window = new RadioButtons();
                    window.f_radio.setVisible(true);
                }
            }
        });
        btnNewButton.setBounds(10, 513, 85, 21);
        panel.add(btnNewButton);
    }

    private void clearFields() {
        textField_sid.setText("");
        textField_sellnam.setText("");
        textField_selpass.setText("");
        textField_sellgen.setText("");
    }


    }
