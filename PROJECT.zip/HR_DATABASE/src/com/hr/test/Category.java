package com.hr.test;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import com.hr.dao.CategoryDao;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Category {
    private static final long serialVersionUID = 1L;
    JFrame frame;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private DefaultTableModel model;
    private JTable table;
    private final JScrollPane scrollPane = new JScrollPane();

    /**
     * Launch the application.
     */
   
     
    public Category() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBackground(new Color(51, 153, 102));
        frame.setBounds(100, 100, 779, 446);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(0, 102, 51));
        panel_1.setBounds(0, 0, 763, 396);
        frame.getContentPane().add(panel_1);
        panel_1.setLayout(null);

        JPanel panel_2 = new JPanel();
        panel_2.setForeground(new Color(255, 255, 255));
        panel_2.setBounds(98, 27, 655, 358);
        panel_1.add(panel_2);
        panel_2.setLayout(null);

        JLabel lblNewLabel = new JLabel("Manage Category");
        lblNewLabel.setForeground(new Color(0, 102, 0));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
        lblNewLabel.setBounds(183, 11, 336, 49);
        panel_2.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("CategoryID");
        lblNewLabel_1.setForeground(new Color(0, 102, 0));
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1.setBounds(47, 70, 83, 24);
        panel_2.add(lblNewLabel_1);

        JLabel lblNewLabel_1_1 = new JLabel("CategoryName");
        lblNewLabel_1_1.setForeground(new Color(0, 102, 0));
        lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_1.setBounds(32, 105, 115, 24);
        panel_2.add(lblNewLabel_1_1);

        JLabel lblNewLabel_1_1_1 = new JLabel("Description");
        lblNewLabel_1_1_1.setForeground(new Color(0, 102, 0));
        lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_1_1.setBounds(377, 70, 83, 24);
        panel_2.add(lblNewLabel_1_1_1);

        textField = new JTextField();
        textField.setBounds(166, 71, 120, 20);
        panel_2.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(166, 108, 120, 20);
        panel_2.add(textField_1);

        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(467, 73, 120, 20);
        panel_2.add(textField_2);

        JButton btnNewButton = new JButton("Add");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    CategoryDao.insert_category(textField.getText(), textField_1.getText(), textField_2.getText());
                    // Optionally, refresh your table data or provide user feedback here
                } catch (Exception e1) {
                    e1.printStackTrace();
                    // Optionally, show an error message to the user
                }
            }
        });
        btnNewButton.setBackground(new Color(0, 102, 0));
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton.setBounds(88, 150, 83, 23);
        panel_2.add(btnNewButton);

        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    CategoryDao.delete_category(textField.getText());
                    // Optionally, refresh your table data or provide user feedback here
                } catch (Exception e1) {
                    e1.printStackTrace();
                    // Optionally, show an error message to the user
                }
            }
        });
        btnDelete.setBackground(new Color(0, 102, 0));
        btnDelete.setForeground(new Color(255, 255, 255));
        btnDelete.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnDelete.setBounds(217, 150, 83, 23);
        panel_2.add(btnDelete);

        JButton btnEdit = new JButton("Edit");
        btnEdit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    CategoryDao.update_category(textField.getText(), textField_1.getText(), textField_2.getText());
                    // Optionally, refresh your table data or provide user feedback here
                } catch (Exception e1) {
                    e1.printStackTrace();
                    // Optionally, show an error message to the user
                }
            }
        });
        btnEdit.setBackground(new Color(0, 102, 0));
        btnEdit.setForeground(new Color(255, 255, 255));
        btnEdit.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnEdit.setBounds(341, 150, 83, 23);
        panel_2.add(btnEdit);

        JButton btnClear = new JButton("Show");
        btnClear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    List<com.hr.bean.Category> categories = CategoryDao.getAllCategories1();
                   
                    for (com.hr.bean.Category category : categories) {
                        model.addRow(new Object[]{
                            category.getCategory_id(),
                            category.getCatageory_name(),
                            category.getDescription()
                        });
                    }
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        btnClear.setBackground(new Color(0, 102, 0));
        btnClear.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnClear.setForeground(new Color(255, 255, 255));
        btnClear.setBounds(467, 150, 83, 23);
        panel_2.add(btnClear);

        scrollPane.setBounds(67, 202, 534, 145);
        panel_2.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);
        model = new DefaultTableModel(
            new Object[][]{},
            new String[]{"CategoryId", "CategoryName", "Description"}
        );
        table.setModel(model);

        final JButton btnNewButton_1 = new JButton("Home");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == btnNewButton_1) {
                    RadioButtons window = new RadioButtons();
                    window.f_radio.setVisible(true);
                }
            }
        });
        btnNewButton_1.setForeground(new Color(0, 102, 51));
        btnNewButton_1.setBackground(new Color(255, 255, 255));
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_1.setBounds(10, 352, 85, 21);
        panel_1.add(btnNewButton_1);

        model = new DefaultTableModel();
        Object[] column = {"CategoryID", "CategoryName", "Description"};
        model.setColumnIdentifiers(column);
    }
}
