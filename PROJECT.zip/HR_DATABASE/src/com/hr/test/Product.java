package com.hr.test;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

import com.hr.dao.ProductsDao;
import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Product {
	private static final long serialVersionUID=1L;
  JFrame frame;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JTextField textField_4;
    private JTable table;

   

    public Product() {
        initialize();
    }
    public JFrame getFrame() {
        return frame;
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 744, 441);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 128, 64));
        panel.setBounds(0, 0, 728, 402);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(255, 255, 255));
        panel_1.setBounds(100, 0, 650, 402);
        panel.add(panel_1);
        panel_1.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Manage Products");
        lblNewLabel.setBounds(176, 20, 284, 37);
        lblNewLabel.setForeground(new Color(0, 128, 64));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
        panel_1.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("ProductID");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1.setForeground(new Color(0, 128, 64));
        lblNewLabel_1.setBounds(29, 65, 104, 24);
        panel_1.add(lblNewLabel_1);
        
        textField = new JTextField();
        textField.setBounds(136, 68, 115, 20);
        panel_1.add(textField);
        textField.setColumns(10);
        
        JLabel lblNewLabel_1_1 = new JLabel("ProductName");
        lblNewLabel_1_1.setForeground(new Color(0, 128, 64));
        lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_1.setBounds(29, 100, 104, 24);
        panel_1.add(lblNewLabel_1_1);
        
        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(136, 100, 115, 20);
        panel_1.add(textField_1);
        
        JLabel lblNewLabel_1_2 = new JLabel("ProductCompany");
        lblNewLabel_1_2.setForeground(new Color(0, 128, 64));
        lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_2.setBounds(275, 65, 115, 24);
        panel_1.add(lblNewLabel_1_2);
        
        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(400, 68, 115, 20);
        panel_1.add(textField_2);
        
        JLabel lblNewLabel_1_2_1 = new JLabel("ProductPrice");
        lblNewLabel_1_2_1.setForeground(new Color(0, 128, 64));
        lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_2_1.setBounds(275, 100, 115, 24);
        panel_1.add(lblNewLabel_1_2_1);
        
        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(400, 103, 115, 20);
        panel_1.add(textField_3);
        
        JLabel lblNewLabel_1_1_1 = new JLabel("ProductQuantity");
        lblNewLabel_1_1_1.setForeground(new Color(0, 128, 64));
        lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_1_1.setBounds(29, 128, 104, 24);
        panel_1.add(lblNewLabel_1_1_1);
        
        textField_4 = new JTextField();
        textField_4.setColumns(10);
        textField_4.setBounds(136, 131, 115, 20);
        panel_1.add(textField_4);
        
        JButton btnNewButton = new JButton("Insert");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 try {
        			 ProductsDao.insert_product(textField.getText(), textField_1.getText(), textField_2.getText(),textField_3.getText(),textField_4.getText());
 		            // Optionally, refresh your table data or provide user feedback here
 		        } catch (Exception e1) {
 		            e1.printStackTrace();
 		            // Optionally, show an error message to the user
 		        }
        	}
        });
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.setBackground(new Color(0, 128, 64));
        btnNewButton.setBounds(275, 135, 89, 23);
        panel_1.add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("Update");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 try {
        			 ProductsDao. update_product(textField.getText(), textField_1.getText(), textField_2.getText(),textField_3.getText(),textField_4.getText());
 		            // Optionally, refresh your table data or provide user feedback here
 		        } catch (Exception e1) {
 		            e1.printStackTrace();
 		            // Optionally, show an error message to the user
 		        }
        	}
        });
        btnNewButton_1.setBackground(new Color(0, 128, 64));
        btnNewButton_1.setForeground(new Color(255, 255, 255));
        btnNewButton_1.setBounds(392, 134, 89, 23);
        panel_1.add(btnNewButton_1);
        
        JButton btnNewButton_2 = new JButton("Delete");
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 try {
        			 ProductsDao.delete_product(textField.getText());
 		            // Optionally, refresh your table data or provide user feedback here
 		        } catch (Exception e1) {
 		            e1.printStackTrace();
 		            // Optionally, show an error message to the user
 		        }
        	}
        });
        btnNewButton_2.setBackground(new Color(0, 128, 64));
        btnNewButton_2.setForeground(new Color(255, 255, 255));
        btnNewButton_2.setBounds(505, 134, 89, 23);
        panel_1.add(btnNewButton_2);
        
        JLabel lblProductsList = new JLabel("Products List");
        lblProductsList.setForeground(new Color(0, 128, 64));
        lblProductsList.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblProductsList.setBounds(236, 183, 154, 37);
        panel_1.add(lblProductsList);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(29, 223, 568, 179);
        panel_1.add(scrollPane);
        
        table = new JTable();
        scrollPane.setViewportView(table);
        table.setModel(new DefaultTableModel(
            new Object[][] {
            },
            new String[] {
                "ID", "Name", "Company", "Quantity", "Price"
            }
        ));
        table.setCellSelectionEnabled(true);

        // Adding an image
                JLabel lblImage = new JLabel();
                lblImage.setBounds(0, 0, 111, 420);
                panel.add(lblImage);
                lblImage.setIcon(new ImageIcon("C:\\Users\\Hp EliteBook 840 G3\\Downloads\\manageproduct.png"));
                
                final JButton btnNewButton_3 = new JButton("Home");
                btnNewButton_3.setBounds(10, 352, 85, 21);
                panel.add(btnNewButton_3);
                btnNewButton_3.addActionListener(new ActionListener() {
                	public void actionPerformed(ActionEvent e) {
                		if(e.getSource()==btnNewButton_3) {
                			RadioButtons window = new RadioButtons();
                            window.f_radio.setVisible(true);
                		}
                	}
                });
                btnNewButton_3.setBackground(new Color(255, 255, 255));
                btnNewButton_3.setForeground(new Color(0, 102, 51));
                btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 16));
                
               
    }
}