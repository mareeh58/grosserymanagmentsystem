package com.hr.test;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Swing {

    private JFrame frame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Swing window = new Swing();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public Swing() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 806, 461);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        final JButton btnNewButton = new JButton("next");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                	
                    LogIn window = new LogIn();
                    window.frame.setVisible(true);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton.setBackground(new Color(0, 102, 51));
        btnNewButton.setBounds(484, 349, 85, 21);
        frame.getContentPane().add(btnNewButton);

        JLabel lblNewLabel = new JLabel("     SHOP SMART ");
        lblNewLabel.setFont(new Font("Snap ITC", Font.BOLD, 29));
        lblNewLabel.setForeground(new Color(0, 102, 0));
        lblNewLabel.setBackground(new Color(0, 153, 51));
        lblNewLabel.setBounds(117, 34, 352, 59);
        frame.getContentPane().add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("GROCERY");
        lblNewLabel_1.setFont(new Font("Snap ITC", Font.BOLD, 28));
        lblNewLabel_1.setForeground(new Color(0, 0, 0));
        lblNewLabel_1.setBounds(306, 91, 247, 31);
        frame.getContentPane().add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("Streamline Your Shopping List");
        lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
        lblNewLabel_2.setBackground(new Color(255, 255, 255));
        lblNewLabel_2.setFont(new Font("Sitka Display", Font.BOLD | Font.ITALIC, 18));
        lblNewLabel_2.setForeground(new Color(0, 102, 51));
        lblNewLabel_2.setBounds(240, 150, 274, 25);
        frame.getContentPane().add(lblNewLabel_2);
 
		
        try {
            ImageIcon image = new ImageIcon("name.jpg");
            JLabel lblNewLabel_4 = new JLabel(new ImageIcon("C:\\Users\\unkno\\Downloads\\Compressed\\name.jpg"));
            lblNewLabel_4.setVerticalAlignment(SwingConstants.TOP);
            lblNewLabel_4.setBounds(10, 0, 780, 411);
            frame.getContentPane().add(lblNewLabel_4);
        } catch (Exception e) {
            System.err.println("Image not found: " + e.getMessage());
            JLabel lblNewLabel_4 = new JLabel("Image not found");
            lblNewLabel_4.setVerticalAlignment(SwingConstants.TOP);
            lblNewLabel_4.setBounds(10, 0, 780, 411);
            frame.getContentPane().add(lblNewLabel_4);
        }
    }
}
