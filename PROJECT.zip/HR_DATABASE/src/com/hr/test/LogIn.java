package com.hr.test;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;



public class LogIn extends Swing{

     JFrame frame;
    private JTextField textField_2;
    private JPanel panel;
    private JPasswordField passwordField;
    JFrame adminFrame;

    /**
     * Launch the application.
     */
   

    /**
     * Create the application.
     */
    public LogIn() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setBackground(new Color(255, 255, 255));
        frame.setBounds(100, 100, 709, 420);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JLabel lblNewLabel = new JLabel("        Login");
        lblNewLabel.setForeground(new Color(0, 102, 51));
        lblNewLabel.setBackground(new Color(0, 102, 0));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
        lblNewLabel.setBounds(329, 34, 206, 46);
        frame.getContentPane().add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("Username");
        lblNewLabel_1.setForeground(new Color(0, 102, 51));
        lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 16));
        lblNewLabel_1.setBounds(245, 135, 85, 24);
        frame.getContentPane().add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("Password");
        lblNewLabel_2.setForeground(new Color(0, 102, 51));
        lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 16));
        lblNewLabel_2.setBounds(245, 180, 85, 13);
        frame.getContentPane().add(lblNewLabel_2);
        
        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(363, 138, 161, 24);
        frame.getContentPane().add(textField_2);
        
        panel = new JPanel();
        panel.setBackground(new Color(0, 102, 0));
        panel.setBounds(0, 0, 216, 383);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        
        JLabel lblNewLabel_3 = new JLabel("Welcome");
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_3.setForeground(new Color(255, 255, 255));
        lblNewLabel_3.setBackground(new Color(255, 255, 255));
        lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 30));
        lblNewLabel_3.setBounds(22, 233, 166, 47);
        panel.add(lblNewLabel_3);
        
        JButton btnNewButton = new JButton("   sign in");
        btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 14));
        btnNewButton.setBounds(428, 290, 0, 29);
        frame.getContentPane().add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("Sign in");
        btnNewButton_1.setForeground(new Color(255, 255, 255));
        btnNewButton_1.setBackground(new Color(0, 102, 51));
        btnNewButton_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
        btnNewButton_1.setBounds(277, 284, 98, 34);
        frame.getContentPane().add(btnNewButton_1);
        
        JButton btnNewButton_1_1 = new JButton("Admin");
        btnNewButton_1_1.setForeground(new Color(255, 255, 255));
        btnNewButton_1_1.setBackground(new Color(0, 102, 51));
        btnNewButton_1_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
        btnNewButton_1_1.setBounds(428, 284, 98, 34);
        frame.getContentPane().add(btnNewButton_1_1);
        
        passwordField = new JPasswordField();
        passwordField.setBounds(363, 174, 161, 24);
        frame.getContentPane().add(passwordField);
        
        // Add action listener to the Admin button
        btnNewButton_1_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	ad_password window = new ad_password();
				window.frame.setVisible(true);   }
        });
        frame.setVisible(true);
    }

}