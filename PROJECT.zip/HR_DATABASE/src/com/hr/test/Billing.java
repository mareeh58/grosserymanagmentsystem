package com.hr.test;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.hr.dao.BillingDao;
import com.hr.dao.CategoryDao;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Billing {

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel_5;
	private JButton btnNewButton_1;
	private JTable table_1;
	private JScrollPane scrollPane_1;
	private JButton btnNewButton;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Billing window = new Billing();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Billing() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */public JFrame getFrame() {
		    return frame;
	 }

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 791, 470);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 102, 51));
		panel.setBounds(0, 0, 777, 435);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 255, 255));
		panel_1.setBounds(92, 11, 675, 418);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("BILLING");
		lblNewLabel.setForeground(new Color(0, 102, 51));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
		lblNewLabel.setBounds(197, 0, 276, 50);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ITEM");
		lblNewLabel_1.setForeground(new Color(0, 102, 51));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(43, 47, 39, 14);
		panel_1.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(105, 45, 118, 20);
		panel_1.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("PRICE");
		lblNewLabel_2.setForeground(new Color(0, 102, 51));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(36, 78, 46, 14);
		panel_1.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(105, 76, 118, 20);
		panel_1.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("QUANTITY");
		lblNewLabel_3.setForeground(new Color(0, 102, 51));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(265, 47, 72, 14);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("CLIENT NAME");
		lblNewLabel_4.setForeground(new Color(0, 102, 51));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setBounds(265, 82, 86, 14);
		panel_1.add(lblNewLabel_4);
		
		textField_2 = new JTextField();
		textField_2.setBounds(361, 45, 112, 20);
		panel_1.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(361, 76, 112, 20);
		panel_1.add(textField_3);
		textField_3.setColumns(10);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 176, 279, 202);
		panel_1.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ITID", "ITNAME", "ITQTY", "ITPRICE", "ITCAT"
			}
		));
		
		lblNewLabel_5 = new JLabel("ITEM LISTS");
		lblNewLabel_5.setForeground(new Color(0, 102, 51));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_5.setBounds(116, 151, 107, 14);
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_7 = new JLabel("BILL");
		lblNewLabel_7.setForeground(new Color(0, 102, 51));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_7.setBounds(449, 153, 46, 14);
		panel_1.add(lblNewLabel_7);
		
		btnNewButton_1 = new JButton("LOGOUT");
		btnNewButton_1.setForeground(new Color(0, 102, 51));
		btnNewButton_1.setBounds(573, 384, 89, 23);
		panel_1.add(btnNewButton_1);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(337, 176, 299, 197);
		panel_1.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "ITEMS", "PRICE", "QTY", "TOTAL"
			}
		));
		
		
		JButton btnNewButton_2 = new JButton("ADD TO BILL");
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setBackground(new Color(0, 102, 51));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
				        try {
				          BillingDao.insert_billing(textField.getText(), textField_1.getText(), textField_2.getText());
				            // Optionally, refresh your table data or provide user feedback here
				        } catch (Exception e1) {
				            e1.printStackTrace();
				            // Optionally, show an error message to the user
				        }
				    }
				});
		btnNewButton_2.setBounds(512, 45, 107, 21);
		panel_1.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("RESET");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
       		 try {
       			BillingDao.delete_billing();
		            // Optionally, refresh your table data or provide user feedback here
		        } catch (Exception e1) {
		            e1.printStackTrace();
		            // Optionally, show an error message to the user
		        }
       	}
       });
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setBackground(new Color(0, 102, 51));
		btnNewButton_3.setBounds(512, 76, 107, 21);
		panel_1.add(btnNewButton_3);
		
		btnNewButton = new JButton("Home");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton) {
        			RadioButtons window = new RadioButtons();
                    window.f_radio.setVisible(true);
        		}
			}
		});
		btnNewButton.setBounds(0, 390, 85, 21);
		panel.add(btnNewButton);
		btnNewButton.setForeground(new Color(0, 102, 51));
		btnNewButton.setBackground(new Color(240, 240, 240));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
	}

	protected static void insert_Billing(String text, String text2, String text3) {
		// TODO Auto-generated method stub
		
	}
}