package com.hr.test;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.UIManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RadioButtons {

    JFrame f_radio;

    /**
     * Launch the application.
     */
   

    /**
     * Create the application.
     */
    public RadioButtons() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
    	f_radio = new JFrame();
    	f_radio.getContentPane().setBackground(new Color(255, 255, 255));
    	f_radio.setBounds(100, 100, 723, 463);
    	f_radio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f_radio.getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 102, 51));
        panel.setBounds(0, 0, 707, 69);
        f_radio.getContentPane().add(panel);

        JLabel lblNewLabel = new JLabel("Shop Smart Grocery");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 34));
        lblNewLabel.setForeground(new Color(255, 255, 255));
        panel.add(lblNewLabel);

        final JRadioButton rdbtnManageProducts = new JRadioButton("Manage Products");
        rdbtnManageProducts.setForeground(new Color(0, 128, 0));
        rdbtnManageProducts.setBackground(new Color(240, 240, 240));
        rdbtnManageProducts.setBounds(62, 130, 128, 23);
        f_radio.getContentPane().add(rdbtnManageProducts);

        JLabel lblImage1 = new JLabel("");
        lblImage1.setBounds(-47, 122, 315, 93); // Adjust the size and position as needed
        ImageIcon icon1 = new ImageIcon("C:\\Users\\Hp EliteBook 840 G3\\Downloads\\Basket finalllll.jpg"); // Provide the path to your first image
        lblImage1.setIcon(icon1);
        f_radio.getContentPane().add(lblImage1);

        final JRadioButton rdbtnManageSeller = new JRadioButton("Manage Seller");
        rdbtnManageSeller.setForeground(new Color(0, 128, 0));
        rdbtnManageSeller.setBackground(UIManager.getColor("Button.background"));
        rdbtnManageSeller.setBounds(62, 249, 128, 23);
        f_radio.getContentPane().add(rdbtnManageSeller);

        JLabel lblImage2 = new JLabel("");
        lblImage2.setBounds(10, 204, 285, 116); // Adjust the size and position as needed
        ImageIcon icon2 = new ImageIcon("C:\\Users\\Hp EliteBook 840 G3\\Downloads\\Color Seller.jpg"); // Provide the path to your second image
        lblImage2.setIcon(icon2);
        f_radio.getContentPane().add(lblImage2);

        JRadioButton rdbtnUserSignup = new JRadioButton("User signUp");
        rdbtnUserSignup.setForeground(new Color(0, 128, 0));
        rdbtnUserSignup.setBackground(UIManager.getColor("Button.background"));
        rdbtnUserSignup.setBounds(338, 130, 128, 23);
        f_radio.getContentPane().add(rdbtnUserSignup);

        JLabel lblImage3 = new JLabel("");
        lblImage3.setBounds(472, 122, 82, 69); // Adjust the size and position as needed
        ImageIcon icon3 = new ImageIcon("C:\\Users\\Hp EliteBook 840 G3\\Documents\\user signup.jpg"); // Provide the path to your third image
        lblImage3.setIcon(icon3);
        f_radio.getContentPane().add(lblImage3);

        final JRadioButton rdbtnManageCategory = new JRadioButton("Manage Category");
        rdbtnManageCategory.setForeground(new Color(0, 128, 0));
        rdbtnManageCategory.setBackground(UIManager.getColor("Button.background"));
        rdbtnManageCategory.setBounds(338, 249, 128, 23);
        f_radio.getContentPane().add(rdbtnManageCategory);

        JLabel lblImage4 = new JLabel("");
        lblImage4.setBounds(471, 100, 300, 190); // Adjust the size and position as needed
        ImageIcon icon4 = new ImageIcon("C:\\Users\\Hp EliteBook 840 G3\\Documents\\category.jpg"); // Provide the path to your fourth image
        lblImage4.setIcon(icon4);
        f_radio.getContentPane().add(lblImage4);

        final JRadioButton rdbtnBilling = new JRadioButton("Billing");
        rdbtnBilling.setForeground(new Color(0, 128, 0));
        rdbtnBilling.setBackground(UIManager.getColor("Button.background"));
        rdbtnBilling.setBounds(241, 350, 128, 23);
        f_radio.getContentPane().add(rdbtnBilling);

        JLabel lblImage5 = new JLabel("");
        lblImage5.setBounds(360, 296, 82, 93); // Adjust the size and position as needed
        ImageIcon icon5 = new ImageIcon("C:\\Users\\Hp EliteBook 840 G3\\Documents\\bill.jpg"); // Provide the path to your fifth image
        lblImage5.setIcon(icon5);
        f_radio.getContentPane().add(lblImage5);

        // Add action listeners to the radio buttons
        rdbtnManageProducts.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	if(e.getSource()==rdbtnManageProducts) {
            		Product window = new Product();
                    window.frame.setVisible(true);
            	}
            }
        });

        rdbtnManageSeller.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	if(e.getSource()==rdbtnManageSeller) {
            		Seller window = new Seller();
					window.frame.setVisible(true);
            	}
            }
        });

       /* rdbtnUserSignup.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	if(e.getSource()==rdbtnUserSignup) {
            		
            	}
            }
        });*/

        rdbtnManageCategory.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              if(e.getSource()==rdbtnManageCategory) {
            	  Category window = new Category();
					window.frame.setVisible(true);
            		
            	}
            }
            
        });


        rdbtnBilling.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
             if(e.getSource()==rdbtnBilling) {
            	 Billing window = new Billing();
					window.frame.setVisible(true);
            		
            	}
            }
        });
    }

    
}